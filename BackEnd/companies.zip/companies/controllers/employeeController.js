// controllers/employeeController.js - Employee Management Controller for Manager Timesheet System
const sql = require('mssql');
const { dbConfig } = require('../../config/db');

// Helper function to get the correct employee table based on company ID
const getEmployeeTable = (companyId) => {
  const tableMap = {
    1: 'CognifyarEmployees',
    2: 'ProphecyOffshoreEmployees', 
    3: 'ProphecyConsultingEmployees'
  };
  return tableMap[parseInt(companyId)] || 'CognifyarEmployees';
};

// Helper function to format dates
const formatDate = (date) => {
  if (!date) return null;
  return new Date(date).toISOString().split('T')[0];
};

// Helper function to generate employee ID
const generateEmployeeId = async (companyId) => {
  try {
    const tableName = getEmployeeTable(companyId);
    const result = await sql.query(`
      SELECT TOP 1 EmployeeId 
      FROM ${tableName} 
      WHERE EmployeeId LIKE 'EMP%'
      ORDER BY CAST(SUBSTRING(EmployeeId, 4, LEN(EmployeeId)) AS INT) DESC
    `);
    
    let maxId = 0;
    if (result.recordset.length > 0) {
      const lastId = result.recordset[0].EmployeeId;
      maxId = parseInt(lastId.replace('EMP', ''));
    }
    
    return `EMP${String(maxId + 1).padStart(3, '0')}`;
  } catch (error) {
    console.error('Error generating employee ID:', error);
    // Fallback to timestamp-based ID
    return `EMP${Date.now().toString().slice(-3)}`;
  }
};

const employeeController = {
  // Test database connection
  testConnection: async (req, res) => {
    try {
      await sql.connect(dbConfig);
      const result = await sql.query('SELECT 1 as test');
      res.json({
        success: true,
        message: 'Employee database connection successful',
        data: result.recordset
      });
    } catch (error) {
      console.error('Employee database connection test failed:', error);
      res.status(500).json({
        success: false,
        message: 'Employee database connection failed',
        error: error.message
      });
    }
  },

  // Get all employees for a specific company
  getAllEmployees: async (req, res) => {
    try {
      await sql.connect(dbConfig);
      const { companyId } = req.params;
      const { status, department, search, limit, offset } = req.query;
      
      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: 'Company ID is required'
        });
      }

      const tableName = getEmployeeTable(companyId);
      let query = `SELECT * FROM ${tableName} WHERE 1=1`;
      let inputs = [];
      
      if (status && status !== 'all') {
        query += ' AND Status = @status';
        inputs.push({ name: 'status', type: sql.NVarChar, value: status });
      }
      
      if (department && department !== 'all') {
        query += ' AND Department = @department';
        inputs.push({ name: 'department', type: sql.NVarChar, value: department });
      }
      
      if (search) {
        query += ` AND (Name LIKE @search 
                      OR Email LIKE @search 
                      OR EmployeeId LIKE @search
                      OR Position LIKE @search)`;
        inputs.push({ name: 'search', type: sql.NVarChar, value: `%${search}%` });
      }
      
      query += ' ORDER BY CreatedAt DESC';
      
      if (limit) {
        query += ` OFFSET ${offset || 0} ROWS FETCH NEXT ${limit} ROWS ONLY`;
      }
      
      const request = new sql.Request();
      inputs.forEach(input => {
        request.input(input.name, input.type, input.value);
      });
      
      const result = await request.query(query);
      
      res.json({
        success: true,
        data: result.recordset,
        count: result.recordset.length,
        companyId: parseInt(companyId)
      });
    } catch (error) {
      console.error('Get all employees error:', error);
      res.status(500).json({ 
        success: false, 
        message: 'Error retrieving employees', 
        error: error.message 
      });
    }
  },

  // Get single employee by ID
  getEmployeeById: async (req, res) => {
    try {
      await sql.connect(dbConfig);
      const { companyId, employeeId } = req.params;
      
      if (!companyId || !employeeId) {
        return res.status(400).json({
          success: false,
          message: 'Company ID and Employee ID are required'
        });
      }

      const tableName = getEmployeeTable(companyId);
      
      const request = new sql.Request();
      request.input('employeeId', sql.NVarChar, employeeId);
      
      const result = await request.query(`
        SELECT * FROM ${tableName} WHERE EmployeeId = @employeeId
      `);
      
      if (result.recordset.length === 0) {
        return res.status(404).json({ 
          success: false, 
          message: 'Employee not found' 
        });
      }
      
      res.json({
        success: true,
        data: result.recordset[0]
      });
    } catch (error) {
      console.error('Get employee by ID error:', error);
      res.status(500).json({ 
        success: false, 
        message: 'Error retrieving employee', 
        error: error.message 
      });
    }
  },

// Create new employee
createEmployee: async (req, res) => {
  try {
    console.log('Creating employee request received');
    console.log('Request body:', req.body);
    
    await sql.connect(dbConfig);
    const { companyId } = req.params;
    
    const {
      name, email, phone, department, position, employmentType = 'Full-time',
      status = 'Active', hireDate, location, employeeId  // ACCEPT employeeId from request
    } = req.body;

    // Validate required fields
    if (!name || !email || !department || !companyId) {
      return res.status(400).json({
        success: false,
        message: 'Name, Email, Department, and Company ID are required fields'
      });
    }

    // VALIDATE EMPLOYEE ID IS PROVIDED
    if (!employeeId || !employeeId.trim()) {
      return res.status(400).json({
        success: false,
        message: 'Employee ID is required'
      });
    }

    const tableName = getEmployeeTable(companyId);
    
    // Check if email already exists in this company
    const checkRequest = new sql.Request();
    checkRequest.input('email', sql.NVarChar, email.toLowerCase());
    const checkResult = await checkRequest.query(`
      SELECT Id FROM ${tableName} WHERE LOWER(Email) = @email
    `);
    
    if (checkResult.recordset.length > 0) {
      return res.status(409).json({
        success: false,
        message: 'An employee with this email already exists in this company'
      });
    }

    // CHECK IF EMPLOYEE ID ALREADY EXISTS
    const idCheckRequest = new sql.Request();
    idCheckRequest.input('employeeId', sql.NVarChar, employeeId.trim());
    const idCheckResult = await idCheckRequest.query(`
      SELECT Id FROM ${tableName} WHERE EmployeeId = @employeeId
    `);
    
    if (idCheckResult.recordset.length > 0) {
      return res.status(409).json({
        success: false,
        message: 'An employee with this ID already exists in this company'
      });
    }

    // USE THE PROVIDED EMPLOYEE ID (not generate a new one)
    const request = new sql.Request();
    request.input('employeeId', sql.NVarChar, employeeId.trim());  // USE PROVIDED ID
    request.input('name', sql.NVarChar, name.trim());
    request.input('email', sql.NVarChar, email.trim().toLowerCase());
    request.input('phone', sql.NVarChar, phone ? phone.trim() : null);
    request.input('department', sql.NVarChar, department.trim());
    request.input('position', sql.NVarChar, position ? position.trim() : null);
    request.input('employmentType', sql.NVarChar, employmentType);
    request.input('status', sql.NVarChar, status);
    request.input('hireDate', sql.Date, hireDate ? new Date(hireDate) : null);
    request.input('location', sql.NVarChar, location ? location.trim() : null);
    request.input('createdAt', sql.DateTime, new Date());
    request.input('updatedAt', sql.DateTime, new Date());
    
    const result = await request.query(`
      INSERT INTO ${tableName} (EmployeeId, Name, Email, Phone, Department, Position, 
                                EmploymentType, Status, HireDate, Location, CreatedAt, UpdatedAt)
      OUTPUT INSERTED.Id
      VALUES (@employeeId, @name, @email, @phone, @department, @position, 
              @employmentType, @status, @hireDate, @location, @createdAt, @updatedAt)
    `);
    
    const newId = result.recordset[0].Id;
    
    // Get the created employee
    const getRequest = new sql.Request();
    getRequest.input('id', sql.Int, newId);
    const getResult = await getRequest.query(`
      SELECT * FROM ${tableName} WHERE Id = @id
    `);
    
    res.status(201).json({
      success: true,
      message: 'Employee created successfully',
      data: getResult.recordset[0]
    });
  } catch (error) {
    console.error('Create employee error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error creating employee: ' + error.message, 
      error: error.message
    });
  }
},

  // Update employee
  updateEmployee: async (req, res) => {
    try {
      console.log('Updating employee request received');
      console.log('Company ID:', req.params.companyId);
      console.log('Employee ID:', req.params.employeeId);
      console.log('Request body:', req.body);
      
      await sql.connect(dbConfig);
      const { companyId, employeeId } = req.params;
      
      const {
        name, email, phone, department, position, employmentType,
        status, hireDate, location
      } = req.body;
      
      // Validate required fields
      if (!name || !email || !department) {
        return res.status(400).json({
          success: false,
          message: 'Name, Email, and Department are required fields'
        });
      }

      const tableName = getEmployeeTable(companyId);
      
      // Check if employee exists
      const checkRequest = new sql.Request();
      checkRequest.input('employeeId', sql.NVarChar, employeeId);
      const checkResult = await checkRequest.query(`
        SELECT * FROM ${tableName} WHERE EmployeeId = @employeeId
      `);
      
      if (checkResult.recordset.length === 0) {
        return res.status(404).json({ 
          success: false, 
          message: 'Employee not found' 
        });
      }
      
      // Check if email already exists for other employees
      const emailCheckRequest = new sql.Request();
      emailCheckRequest.input('email', sql.NVarChar, email.toLowerCase());
      emailCheckRequest.input('employeeId', sql.NVarChar, employeeId);
      const emailCheckResult = await emailCheckRequest.query(`
        SELECT Id FROM ${tableName} WHERE LOWER(Email) = @email AND EmployeeId != @employeeId
      `);
      
      if (emailCheckResult.recordset.length > 0) {
        return res.status(409).json({
          success: false,
          message: 'Another employee with this email already exists in this company'
        });
      }
      
      const request = new sql.Request();
      request.input('employeeId', sql.NVarChar, employeeId);
      request.input('name', sql.NVarChar, name.trim());
      request.input('email', sql.NVarChar, email.trim().toLowerCase());
      request.input('phone', sql.NVarChar, phone ? phone.trim() : null);
      request.input('department', sql.NVarChar, department.trim());
      request.input('position', sql.NVarChar, position ? position.trim() : null);
      request.input('employmentType', sql.NVarChar, employmentType || 'Full-time');
      request.input('status', sql.NVarChar, status || 'Active');
      request.input('hireDate', sql.Date, hireDate ? new Date(hireDate) : null);
      request.input('location', sql.NVarChar, location ? location.trim() : null);
      request.input('updatedAt', sql.DateTime, new Date());
      
      const result = await request.query(`
        UPDATE ${tableName} 
        SET Name = @name, 
            Email = @email, 
            Phone = @phone, 
            Department = @department, 
            Position = @position, 
            EmploymentType = @employmentType, 
            Status = @status, 
            HireDate = @hireDate, 
            Location = @location, 
            UpdatedAt = @updatedAt
        WHERE EmployeeId = @employeeId
      `);
      
      if (result.rowsAffected[0] === 0) {
        return res.status(404).json({ 
          success: false, 
          message: 'Employee not found or no changes made' 
        });
      }
      
      // Get updated employee
      const getRequest = new sql.Request();
      getRequest.input('employeeId', sql.NVarChar, employeeId);
      const getResult = await getRequest.query(`
        SELECT * FROM ${tableName} WHERE EmployeeId = @employeeId
      `);
      
      res.json({
        success: true,
        message: 'Employee updated successfully',
        data: getResult.recordset[0]
      });
    } catch (error) {
      console.error('Update employee error:', error);
      res.status(500).json({ 
        success: false, 
        message: 'Error updating employee', 
        error: error.message 
      });
    }
  },

  // Update employee status
  updateEmployeeStatus: async (req, res) => {
    try {
      console.log('=== UPDATE EMPLOYEE STATUS REQUEST ===');
      console.log('Company ID:', req.params.companyId);
      console.log('Employee ID:', req.params.employeeId);
      console.log('Request Body:', req.body);
      
      await sql.connect(dbConfig);
      const { companyId, employeeId } = req.params;
      const { status } = req.body;
      
      // Validate inputs
      if (!companyId || !employeeId) {
        return res.status(400).json({
          success: false,
          message: 'Company ID and Employee ID are required'
        });
      }
      
      if (!status) {
        return res.status(400).json({
          success: false,
          message: 'Status is required'
        });
      }
      
      // Valid statuses
      const validStatuses = ['Active', 'Inactive', 'On Leave'];
      if (!validStatuses.includes(status)) {
        return res.status(400).json({
          success: false,
          message: `Status must be one of: ${validStatuses.join(', ')}`
        });
      }

      const tableName = getEmployeeTable(companyId);
      
      // Check if employee exists first
      const checkRequest = new sql.Request();
      checkRequest.input('employeeId', sql.NVarChar, employeeId);
      const checkResult = await checkRequest.query(`
        SELECT EmployeeId, Status FROM ${tableName} WHERE EmployeeId = @employeeId
      `);
      
      if (checkResult.recordset.length === 0) {
        return res.status(404).json({ 
          success: false, 
          message: 'Employee not found' 
        });
      }
      
      // Update the status
      const request = new sql.Request();
      request.input('employeeId', sql.NVarChar, employeeId);
      request.input('status', sql.NVarChar, status);
      request.input('updatedAt', sql.DateTime, new Date());
      
      const result = await request.query(`
        UPDATE ${tableName} 
        SET Status = @status, UpdatedAt = @updatedAt
        WHERE EmployeeId = @employeeId
      `);
      
      if (result.rowsAffected[0] === 0) {
        return res.status(404).json({ 
          success: false, 
          message: 'Employee not found or no changes made' 
        });
      }
      
      // Get updated employee data
      const getRequest = new sql.Request();
      getRequest.input('employeeId', sql.NVarChar, employeeId);
      const getResult = await getRequest.query(`
        SELECT * FROM ${tableName} WHERE EmployeeId = @employeeId
      `);
      
      res.json({
        success: true,
        message: `Employee status updated to ${status} successfully`,
        data: getResult.recordset[0]
      });
    } catch (error) {
      console.error('=== UPDATE EMPLOYEE STATUS ERROR ===');
      console.error('Error details:', error);
      
      res.status(500).json({ 
        success: false, 
        message: 'Error updating employee status', 
        error: error.message
      });
    }
  },

  // Delete employee
  // deleteEmployee: async (req, res) => {
  //   try {
  //     await sql.connect(dbConfig);
  //     const { companyId, employeeId } = req.params;
      
  //     if (!companyId || !employeeId) {
  //       return res.status(400).json({
  //         success: false,
  //         message: 'Company ID and Employee ID are required'
  //       });
  //     }

  //     const tableName = getEmployeeTable(companyId);
      
  //     // Check if employee exists
  //     const checkRequest = new sql.Request();
  //     checkRequest.input('employeeId', sql.NVarChar, employeeId);
  //     const checkResult = await checkRequest.query(`
  //       SELECT * FROM ${tableName} WHERE EmployeeId = @employeeId
  //     `);
      
  //     if (checkResult.recordset.length === 0) {
  //       return res.status(404).json({ 
  //         success: false, 
  //         message: 'Employee not found' 
  //       });
  //     }
      
  //     // Check if employee has timesheets
  //     const timesheetCheckRequest = new sql.Request();
  //     timesheetCheckRequest.input('employeeId', sql.NVarChar, employeeId);
  //     const timesheetCheckResult = await timesheetCheckRequest.query(`
  //       SELECT COUNT(*) as TimesheetCount FROM Timesheets WHERE EmployeeId = @employeeId
  //     `);
      
  //     const timesheetCount = timesheetCheckResult.recordset[0].TimesheetCount;
  //     if (timesheetCount > 0) {
  //       return res.status(409).json({
  //         success: false,
  //         message: `Cannot delete employee. Employee has ${timesheetCount} timesheet(s) associated.`,
  //         hasTimesheets: true,
  //         timesheetCount: timesheetCount
  //       });
  //     }
      
  //     const request = new sql.Request();
  //     request.input('employeeId', sql.NVarChar, employeeId);
      
  //     const result = await request.query(`
  //       DELETE FROM ${tableName} WHERE EmployeeId = @employeeId
  //     `);
      
  //     res.json({
  //       success: true,
  //       message: 'Employee deleted successfully'
  //     });
  //   } catch (error) {
  //     console.error('Delete employee error:', error);
  //     res.status(500).json({ 
  //       success: false, 
  //       message: 'Error deleting employee', 
  //       error: error.message 
  //     });
  //   }
  // },


  // Delete employee
deleteEmployee: async (req, res) => {
  try {
    await sql.connect(dbConfig);
    const { companyId, employeeId } = req.params;
    
    if (!companyId || !employeeId) {
      return res.status(400).json({
        success: false,
        message: 'Company ID and Employee ID are required'
      });
    }

    const tableName = getEmployeeTable(companyId);
    
    // Check if employee exists
    const checkRequest = new sql.Request();
    checkRequest.input('employeeId', sql.NVarChar, employeeId);
    const checkResult = await checkRequest.query(`
      SELECT * FROM ${tableName} WHERE EmployeeId = @employeeId
    `);
    
    if (checkResult.recordset.length === 0) {
      return res.status(404).json({ 
        success: false, 
        message: 'Employee not found' 
      });
    }
    
    // Check if employee has timesheets
    const timesheetCheckRequest = new sql.Request();
    timesheetCheckRequest.input('employeeId', sql.NVarChar, employeeId);
    const timesheetCheckResult = await timesheetCheckRequest.query(`
      SELECT COUNT(*) as TimesheetCount FROM Timesheets WHERE EmployeeId = @employeeId
    `);
    
    const timesheetCount = timesheetCheckResult.recordset[0].TimesheetCount;
    
    if (timesheetCount > 0) {
      // DELETE ALL TIMESHEETS FIRST (CASCADE DELETE)
      const deleteTimesheetsRequest = new sql.Request();
      deleteTimesheetsRequest.input('employeeId', sql.NVarChar, employeeId);
      await deleteTimesheetsRequest.query(`
        DELETE FROM Timesheets WHERE EmployeeId = @employeeId
      `);
      
      console.log(`Deleted ${timesheetCount} timesheet(s) for employee ${employeeId}`);
    }
    
    // Now delete the employee
    const request = new sql.Request();
    request.input('employeeId', sql.NVarChar, employeeId);
    
    const result = await request.query(`
      DELETE FROM ${tableName} WHERE EmployeeId = @employeeId
    `);
    
    res.json({
      success: true,
      message: timesheetCount > 0 
        ? `Employee and ${timesheetCount} associated timesheet(s) deleted successfully`
        : 'Employee deleted successfully',
      deletedTimesheets: timesheetCount
    });
  } catch (error) {
    console.error('Delete employee error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error deleting employee', 
      error: error.message 
    });
  }
},

  // Get employees by department
  getEmployeesByDepartment: async (req, res) => {
    try {
      await sql.connect(dbConfig);
      const { companyId, department } = req.params;
      
      if (!companyId || !department) {
        return res.status(400).json({
          success: false,
          message: 'Company ID and Department are required'
        });
      }

      const tableName = getEmployeeTable(companyId);
      
      const request = new sql.Request();
      request.input('department', sql.NVarChar, department);
      
      const result = await request.query(`
        SELECT * FROM ${tableName} 
        WHERE Department = @department
        ORDER BY Name ASC
      `);
      
      res.json({
        success: true,
        data: result.recordset,
        count: result.recordset.length,
        department: department,
        companyId: parseInt(companyId)
      });
    } catch (error) {
      console.error('Get employees by department error:', error);
      res.status(500).json({ 
        success: false, 
        message: 'Error retrieving employees by department', 
        error: error.message 
      });
    }
  },

  // Search employees
  searchEmployees: async (req, res) => {
    try {
      await sql.connect(dbConfig);
      const { companyId } = req.params;
      const { q, limit = 50 } = req.query;
      
      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: 'Company ID is required'
        });
      }
      
      if (!q || q.trim().length < 2) {
        return res.status(400).json({
          success: false,
          message: 'Search query must be at least 2 characters long'
        });
      }

      const tableName = getEmployeeTable(companyId);
      
      const request = new sql.Request();
      request.input('search', sql.NVarChar, `%${q.trim()}%`);
      request.input('limit', sql.Int, parseInt(limit));
      
      const result = await request.query(`
        SELECT TOP (@limit) * FROM ${tableName}
        WHERE Name LIKE @search 
           OR Email LIKE @search 
           OR EmployeeId LIKE @search
           OR Position LIKE @search
           OR Department LIKE @search
        ORDER BY Name ASC
      `);
      
      res.json({
        success: true,
        data: result.recordset,
        count: result.recordset.length,
        searchTerm: q,
        companyId: parseInt(companyId)
      });
    } catch (error) {
      console.error('Search employees error:', error);
      res.status(500).json({ 
        success: false, 
        message: 'Error searching employees', 
        error: error.message 
      });
    }
  },

  // Get employee statistics
  getEmployeeStats: async (req, res) => {
    try {
      await sql.connect(dbConfig);
      const { companyId } = req.params;
      
      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: 'Company ID is required'
        });
      }

      const tableName = getEmployeeTable(companyId);
      
      const result = await sql.query(`
        SELECT 
          COUNT(*) as total,
          SUM(CASE WHEN Status = 'Active' THEN 1 ELSE 0 END) as active,
          SUM(CASE WHEN Status = 'Inactive' THEN 1 ELSE 0 END) as inactive,
          SUM(CASE WHEN Status = 'On Leave' THEN 1 ELSE 0 END) as onLeave,
          COUNT(DISTINCT Department) as departments,
          SUM(CASE WHEN EmploymentType = 'Full-time' THEN 1 ELSE 0 END) as fullTime,
          SUM(CASE WHEN EmploymentType = 'Part-time' THEN 1 ELSE 0 END) as partTime,
          SUM(CASE WHEN EmploymentType = 'Contract' THEN 1 ELSE 0 END) as contract
        FROM ${tableName}
      `);
      
      res.json({
        success: true,
        data: result.recordset[0],
        companyId: parseInt(companyId)
      });
    } catch (error) {
      console.error('Get employee stats error:', error);
      res.status(500).json({ 
        success: false, 
        message: 'Error retrieving employee statistics', 
        error: error.message 
      });
    }
  },
  // Fixed controller methods for employee details

getEmployeeDetails: async (req, res) => {
  try {
    await sql.connect(dbConfig);
    const { companyId, employeeId } = req.params;
    
    if (!companyId || !employeeId) {
      return res.status(400).json({
        success: false,
        message: 'Company ID and Employee ID are required'
      });
    }

    const tableName = getEmployeeTable(companyId);
    
    // FIX: The employeeId from URL is the database Id (numeric)
    const employeeRequest = new sql.Request();
    employeeRequest.input('employeeId', sql.Int, parseInt(employeeId)); // Changed to Int
    
    const employeeResult = await employeeRequest.query(`
      SELECT * FROM ${tableName} WHERE Id = @employeeId
    `);
    
    if (employeeResult.recordset.length === 0) {
      return res.status(404).json({ 
        success: false, 
        message: 'Employee not found' 
      });
    }

    const employee = employeeResult.recordset[0];

    // Rest of the code remains the same...
    const timesheetRequest = new sql.Request();
    timesheetRequest.input('employeeIdCode', sql.NVarChar, employee.EmployeeId);
    const timesheetResult = await timesheetRequest.query(`
      SELECT COUNT(*) as TimesheetCount,
             SUM(CASE WHEN Status = 'Pending' THEN 1 ELSE 0 END) as PendingCount,
             SUM(CASE WHEN Status = 'Approved' THEN 1 ELSE 0 END) as ApprovedCount,
             SUM(CASE WHEN Status = 'Rejected' THEN 1 ELSE 0 END) as RejectedCount
      FROM Timesheets 
      WHERE EmployeeId = @employeeIdCode
    `);

    const externalTimesheetRequest = new sql.Request();
    externalTimesheetRequest.input('employeeIdCode', sql.NVarChar, employee.EmployeeId);
    const externalTimesheetResult = await externalTimesheetRequest.query(`
      SELECT COUNT(*) as ExternalTimesheetCount
      FROM ExternalTimesheetFiles 
      WHERE EmployeeId = @employeeIdCode
    `);

    const statementRequest = new sql.Request();
    statementRequest.input('employeeIdCode', sql.NVarChar, employee.EmployeeId);
    const statementResult = await statementRequest.query(`
      SELECT COUNT(*) as StatementCount
      FROM EmployeePayStructure 
      WHERE EmployeeId = @employeeIdCode
    `);

    res.json({
      success: true,
      data: {
        employee: employee,
        stats: {
          timesheets: {
            total: timesheetResult.recordset[0].TimesheetCount || 0,
            pending: timesheetResult.recordset[0].PendingCount || 0,
            approved: timesheetResult.recordset[0].ApprovedCount || 0,
            rejected: timesheetResult.recordset[0].RejectedCount || 0
          },
          externalTimesheets: externalTimesheetResult.recordset[0].ExternalTimesheetCount || 0,
          statements: statementResult.recordset[0].StatementCount || 0
        }
      }
    });
  } catch (error) {
    console.error('Get employee details error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error retrieving employee details', 
      error: error.message 
    });
  }
},

getEmployeeTimesheets: async (req, res) => {
  try {
    await sql.connect(dbConfig);
    const { companyId, employeeId } = req.params;
    const { status, startDate, endDate } = req.query;
    
    if (!companyId || !employeeId) {
      return res.status(400).json({
        success: false,
        message: 'Company ID and Employee ID are required'
      });
    }

    const tableName = getEmployeeTable(companyId);
    
    // First get the employee's EmployeeId code
    const empRequest = new sql.Request();
    empRequest.input('id', sql.Int, parseInt(employeeId));
    const empResult = await empRequest.query(`SELECT EmployeeId FROM ${tableName} WHERE Id = @id`);
    
    if (empResult.recordset.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Employee not found'
      });
    }
    
    const employeeIdCode = empResult.recordset[0].EmployeeId;

    let query = `
      SELECT t.*, e.Name as EmployeeName, e.Email as EmployeeEmail
      FROM Timesheets t
      INNER JOIN ${tableName} e ON t.EmployeeId = e.EmployeeId
      WHERE t.EmployeeId = @employeeIdCode
    `;
    
    const request = new sql.Request();
    request.input('employeeIdCode', sql.NVarChar, employeeIdCode);
    
    if (status && status !== 'all') {
      query += ' AND t.Status = @status';
      request.input('status', sql.NVarChar, status);
    }
    
    if (startDate) {
      query += ' AND t.PeriodStart >= @startDate';
      request.input('startDate', sql.Date, new Date(startDate));
    }
    
    if (endDate) {
      query += ' AND t.PeriodEnd <= @endDate';
      request.input('endDate', sql.Date, new Date(endDate));
    }
    
    query += ' ORDER BY t.PeriodStart DESC';
    
    const result = await request.query(query);
    
    res.json({
      success: true,
      data: result.recordset,
      count: result.recordset.length
    });
  } catch (error) {
    console.error('Get employee timesheets error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error retrieving employee timesheets', 
      error: error.message 
    });
  }
},

getEmployeeExternalTimesheets: async (req, res) => {
  try {
    await sql.connect(dbConfig);
    const { companyId, employeeId } = req.params;
    
    if (!companyId || !employeeId) {
      return res.status(400).json({
        success: false,
        message: 'Company ID and Employee ID are required'
      });
    }

    const tableName = getEmployeeTable(companyId);
    
    // Get employee's EmployeeId code
    const empRequest = new sql.Request();
    empRequest.input('id', sql.Int, parseInt(employeeId));
    const empResult = await empRequest.query(`SELECT EmployeeId FROM ${tableName} WHERE Id = @id`);
    
    if (empResult.recordset.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Employee not found'
      });
    }
    
    const employeeIdCode = empResult.recordset[0].EmployeeId;

    const request = new sql.Request();
    request.input('employeeIdCode', sql.NVarChar, employeeIdCode);
    
    const result = await request.query(`
      SELECT * FROM ExternalTimesheetFiles 
      WHERE EmployeeId = @employeeIdCode
      ORDER BY UploadDate DESC
    `);
    
    res.json({
      success: true,
      data: result.recordset,
      count: result.recordset.length
    });
  } catch (error) {
    console.error('Get employee external timesheets error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error retrieving external timesheets', 
      error: error.message 
    });
  }
},

getEmployeeStatements: async (req, res) => {
  try {
    await sql.connect(dbConfig);
    const { companyId, employeeId } = req.params;
    const { startDate, endDate } = req.query;
    
    if (!companyId || !employeeId) {
      return res.status(400).json({
        success: false,
        message: 'Company ID and Employee ID are required'
      });
    }

    const tableName = getEmployeeTable(companyId);
    
    // Get employee's EmployeeId code
    const empRequest = new sql.Request();
    empRequest.input('id', sql.Int, parseInt(employeeId));
    const empResult = await empRequest.query(`SELECT EmployeeId FROM ${tableName} WHERE Id = @id`);
    
    if (empResult.recordset.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Employee not found'
      });
    }
    
    const employeeIdCode = empResult.recordset[0].EmployeeId;

    let query = `
      SELECT * FROM EmployeePayStructure 
      WHERE EmployeeId = @employeeIdCode
    `;
    
    const request = new sql.Request();
    request.input('employeeIdCode', sql.NVarChar, employeeIdCode);
    
    if (startDate) {
      query += ' AND CheckDate >= @startDate';
      request.input('startDate', sql.Date, new Date(startDate));
    }
    
    if (endDate) {
      query += ' AND CheckDate <= @endDate';
      request.input('endDate', sql.Date, new Date(endDate));
    }
    
    query += ' ORDER BY CheckDate DESC';
    
    const result = await request.query(query);
    
    res.json({
      success: true,
      data: result.recordset,
      count: result.recordset.length
    });
  } catch (error) {
    console.error('Get employee statements error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error retrieving employee statements', 
      error: error.message 
    });
  }
},

getEmployeeReports: async (req, res) => {
  try {
    await sql.connect(dbConfig);
    const { companyId, employeeId } = req.params;
    
    if (!companyId || !employeeId) {
      return res.status(400).json({
        success: false,
        message: 'Company ID and Employee ID are required'
      });
    }

    const tableName = getEmployeeTable(companyId);
    
    // Get employee's EmployeeId code
    const empRequest = new sql.Request();
    empRequest.input('id', sql.Int, parseInt(employeeId));
    const empResult = await empRequest.query(`SELECT EmployeeId FROM ${tableName} WHERE Id = @id`);
    
    if (empResult.recordset.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Employee not found'
      });
    }
    
    const employeeIdCode = empResult.recordset[0].EmployeeId;

    const request = new sql.Request();
    request.input('employeeIdCode', sql.NVarChar, employeeIdCode);
    
    const result = await request.query(`
      SELECT * FROM EmployeeReports 
      WHERE EmployeeId = @employeeIdCode
      ORDER BY UploadDate DESC
    `);
    
    res.json({
      success: true,
      data: result.recordset,
      count: result.recordset.length
    });
  } catch (error) {
    console.error('Get employee reports error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error retrieving employee reports', 
      error: error.message 
    });
  }
},

deleteExternalTimesheet: async (req, res) => {
  try {
    await sql.connect(dbConfig);
    const { companyId, employeeId, timesheetId } = req.params;
    
    if (!companyId || !employeeId || !timesheetId) {
      return res.status(400).json({
        success: false,
        message: 'Company ID, Employee ID, and Timesheet ID are required'
      });
    }

    const tableName = getEmployeeTable(companyId);
    
    // Get employee's EmployeeId code
    const empRequest = new sql.Request();
    empRequest.input('id', sql.Int, parseInt(employeeId));
    const empResult = await empRequest.query(`SELECT EmployeeId FROM ${tableName} WHERE Id = @id`);
    
    if (empResult.recordset.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Employee not found'
      });
    }
    
    const employeeIdCode = empResult.recordset[0].EmployeeId;

    const request = new sql.Request();
    request.input('timesheetId', sql.Int, parseInt(timesheetId));
    request.input('employeeIdCode', sql.NVarChar, employeeIdCode);
    
    const result = await request.query(`
      DELETE FROM ExternalTimesheetFiles 
      WHERE Id = @timesheetId AND EmployeeId = @employeeIdCode
    `);
    
    if (result.rowsAffected[0] === 0) {
      return res.status(404).json({
        success: false,
        message: 'External timesheet not found'
      });
    }
    
    res.json({
      success: true,
      message: 'External timesheet deleted successfully'
    });
  } catch (error) {
    console.error('Delete external timesheet error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error deleting external timesheet', 
      error: error.message 
    });
  }
},

deleteReport: async (req, res) => {
  try {
    await sql.connect(dbConfig);
    const { companyId, employeeId, reportId } = req.params;
    
    if (!companyId || !employeeId || !reportId) {
      return res.status(400).json({
        success: false,
        message: 'Company ID, Employee ID, and Report ID are required'
      });
    }

    const tableName = getEmployeeTable(companyId);
    
    // Get employee's EmployeeId code
    const empRequest = new sql.Request();
    empRequest.input('id', sql.Int, parseInt(employeeId));
    const empResult = await empRequest.query(`SELECT EmployeeId FROM ${tableName} WHERE Id = @id`);
    
    if (empResult.recordset.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Employee not found'
      });
    }
    
    const employeeIdCode = empResult.recordset[0].EmployeeId;

    const request = new sql.Request();
    request.input('reportId', sql.Int, parseInt(reportId));
    request.input('employeeIdCode', sql.NVarChar, employeeIdCode);
    
    const result = await request.query(`
      DELETE FROM EmployeeReports 
      WHERE Id = @reportId AND EmployeeId = @employeeIdCode
    `);
    
    if (result.rowsAffected[0] === 0) {
      return res.status(404).json({
        success: false,
        message: 'Report not found'
      });
    }
    
    res.json({
      success: true,
      message: 'Report deleted successfully'
    });
  } catch (error) {
    console.error('Delete report error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error deleting report', 
      error: error.message 
    });
  }
},

deleteStatement: async (req, res) => {
  try {
    await sql.connect(dbConfig);
    const { companyId, employeeId, statementId } = req.params;
    
    if (!companyId || !employeeId || !statementId) {
      return res.status(400).json({
        success: false,
        message: 'Company ID, Employee ID, and Statement ID are required'
      });
    }

    const tableName = getEmployeeTable(companyId);
    
    // Get employee's EmployeeId code
    const empRequest = new sql.Request();
    empRequest.input('id', sql.Int, parseInt(employeeId));
    const empResult = await empRequest.query(`SELECT EmployeeId FROM ${tableName} WHERE Id = @id`);
    
    if (empResult.recordset.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Employee not found'
      });
    }
    
    const employeeIdCode = empResult.recordset[0].EmployeeId;

    const request = new sql.Request();
    request.input('statementId', sql.Int, parseInt(statementId));
    request.input('employeeIdCode', sql.NVarChar, employeeIdCode);
    
    const result = await request.query(`
      DELETE FROM EmployeePayStructure 
      WHERE Id = @statementId AND EmployeeId = @employeeIdCode
    `);
    
    if (result.rowsAffected[0] === 0) {
      return res.status(404).json({
        success: false,
        message: 'Statement not found'
      });
    }
    
    res.json({
      success: true,
      message: 'Statement deleted successfully'
    });
  } catch (error) {
    console.error('Delete statement error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error deleting statement', 
      error: error.message 
    });
  }
}
  
};

module.exports = employeeController;
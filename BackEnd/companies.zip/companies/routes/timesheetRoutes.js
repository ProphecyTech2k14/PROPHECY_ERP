// routes/timesheetRoutes.js - Timesheet Routes for Manager Timesheet System
const express = require('express');
const router = express.Router();
const timesheetController = require('../controllers/timesheetController');
const { authenticateToken } = require('../../Recruitment/middleWare/authMiddleware');

// Middleware to log all requests
router.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] Timesheet Route: ${req.method} ${req.originalUrl}`);
  console.log('Query params:', req.query);
  if (req.method !== 'GET') {
    console.log('Body:', req.body);
  }
  next();
});

// Apply authentication middleware to all routes except test endpoints
router.use((req, res, next) => {
  // Skip auth for test endpoints
  if (req.path === '/test/connection') {
    return next();
  }
  return authenticateToken(req, res, next);
});

// TEST ENDPOINT - Check database connection (no auth required)
router.get('/test/connection', timesheetController.testConnection);

// Timesheet management routes

// GET /api/timesheets/pending - Get pending timesheets (for notifications)
router.get('/pending', timesheetController.getPendingTimesheets);

// GET /api/timesheets/stats - Get timesheet statistics
router.get('/stats', timesheetController.getTimesheetStats);

// GET /api/timesheets/company/:companyId - Get timesheets for a specific company
router.get('/company/:companyId', timesheetController.getTimesheetsByCompany);

// GET /api/timesheets/employee/:employeeId - Get timesheets for a specific employee
router.get('/employee/:employeeId', timesheetController.getTimesheetsByEmployee);

// POST /api/timesheets/bulk/approve - Bulk approve timesheets
router.post('/bulk/approve', (req, res, next) => {
  console.log('=== BULK APPROVE ROUTE MIDDLEWARE DEBUG ===');
  console.log('Request body:', req.body);
  console.log('Headers:', req.headers);
  next();
}, timesheetController.bulkApproveTimesheets);

// POST /api/timesheets/bulk/reject - Bulk reject timesheets
router.post('/bulk/reject', (req, res, next) => {
  console.log('=== BULK REJECT ROUTE MIDDLEWARE DEBUG ===');
  console.log('Request body:', req.body);
  console.log('Headers:', req.headers);
  next();
}, timesheetController.bulkRejectTimesheets);

// GET /api/timesheets - Get all timesheets with optional filters
router.get('/', timesheetController.getAllTimesheets);

// GET /api/timesheets/:id - Get single timesheet by ID
router.get('/:id', timesheetController.getTimesheetById);

// POST /api/timesheets - Create new timesheet
router.post('/', timesheetController.createTimesheet);

// PUT /api/timesheets/:id - Update timesheet
router.put('/:id', timesheetController.updateTimesheet);

// PATCH /api/timesheets/:id/status - Update timesheet status (approve/reject)
router.patch('/:id/status', (req, res, next) => {
  console.log('=== TIMESHEET STATUS ROUTE MIDDLEWARE DEBUG ===');
  console.log('Timesheet ID:', req.params.id);
  console.log('Body:', req.body);
  console.log('Headers:', req.headers);
  next();
}, timesheetController.updateTimesheetStatus);

// PATCH /api/timesheets/:id/select - Toggle timesheet selection
router.patch('/:id/select', timesheetController.toggleTimesheetSelection);

// DELETE /api/timesheets/:id - Delete timesheet
router.delete('/:id', timesheetController.deleteTimesheet);

// Error handling middleware
router.use((error, req, res, next) => {
  console.error('Timesheet route error:', error);
  res.status(500).json({
    success: false,
    message: 'Internal server error in timesheet routes',
    error: error.message
  });
});

module.exports = router;
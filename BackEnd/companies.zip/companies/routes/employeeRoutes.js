// routes/employeeRoutes.js - Employee Routes for Manager Timesheet System
const express = require('express');
const router = express.Router();
const employeeController = require('../controllers/employeeController');
const { authenticateToken } = require('../../Recruitment/middleWare/authMiddleware');

// Middleware to log all requests
router.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] Employee Route: ${req.method} ${req.originalUrl}`);
  console.log('Query params:', req.query);
  if (req.method !== 'GET') {
    console.log('Body:', req.body);
  }
  next();
});

// Apply authentication middleware to all routes except test endpoints
router.use((req, res, next) => {
  // Skip auth for test endpoints
  if (req.path === '/test/connection') {
    return next();
  }
  return authenticateToken(req, res, next);
});

// TEST ENDPOINT - Check database connection (no auth required)
router.get('/test/connection', employeeController.testConnection);

// Employee management routes for specific company

// GET /api/employees/company/:companyId/search - Search employees in a company
router.get('/company/:companyId/search', employeeController.searchEmployees);

// GET /api/employees/company/:companyId/stats - Get employee statistics for a company
router.get('/company/:companyId/stats', employeeController.getEmployeeStats);

// GET /api/employees/company/:companyId/department/:department - Get employees by department
router.get('/company/:companyId/department/:department', employeeController.getEmployeesByDepartment);

// GET /api/employees/company/:companyId - Get all employees for a company
router.get('/company/:companyId', employeeController.getAllEmployees);

// GET /api/employees/company/:companyId/:employeeId - Get single employee by company and employee ID
router.get('/company/:companyId/:employeeId', employeeController.getEmployeeById);

// POST /api/employees/company/:companyId - Create new employee in a company
router.post('/company/:companyId', employeeController.createEmployee);

// PUT /api/employees/company/:companyId/:employeeId - Update employee
router.put('/company/:companyId/:employeeId', employeeController.updateEmployee);

// Add these routes after the existing employee routes

// Employee detail page routes
// GET /api/employees/company/:companyId/:employeeId/details - Get employee with all related data
router.get('/company/:companyId/:employeeId/details', employeeController.getEmployeeDetails);

// GET /api/employees/company/:companyId/:employeeId/timesheets - Get internal timesheets
router.get('/company/:companyId/:employeeId/timesheets', employeeController.getEmployeeTimesheets);

// GET /api/employees/company/:companyId/:employeeId/external-timesheets - Get external timesheets
router.get('/company/:companyId/:employeeId/external-timesheets', employeeController.getEmployeeExternalTimesheets);

// GET /api/employees/company/:companyId/:employeeId/statements - Get payroll statements
router.get('/company/:companyId/:employeeId/statements', employeeController.getEmployeeStatements);

// GET /api/employees/company/:companyId/:employeeId/reports - Get reports
router.get('/company/:companyId/:employeeId/reports', employeeController.getEmployeeReports);

// DELETE /api/employees/company/:companyId/:employeeId/external-timesheets/:timesheetId - Delete external timesheet
router.delete('/company/:companyId/:employeeId/external-timesheets/:timesheetId', employeeController.deleteExternalTimesheet);

// DELETE /api/employees/company/:companyId/:employeeId/reports/:reportId - Delete report
router.delete('/company/:companyId/:employeeId/reports/:reportId', employeeController.deleteReport);

// DELETE /api/employees/company/:companyId/:employeeId/statements/:statementId - Delete statement
router.delete('/company/:companyId/:employeeId/statements/:statementId', employeeController.deleteStatement);

// PATCH /api/employees/company/:companyId/:employeeId/status - Update employee status only
router.patch('/company/:companyId/:employeeId/status', (req, res, next) => {
  console.log('=== EMPLOYEE STATUS ROUTE MIDDLEWARE DEBUG ===');
  console.log('Company ID:', req.params.companyId);
  console.log('Employee ID:', req.params.employeeId);
  console.log('Body:', req.body);
  console.log('Headers:', req.headers);
  next();
}, employeeController.updateEmployeeStatus);

// DELETE /api/employees/company/:companyId/:employeeId - Delete employee
router.delete('/company/:companyId/:employeeId', employeeController.deleteEmployee);

// Error handling middleware
router.use((error, req, res, next) => {
  console.error('Employee route error:', error);
  res.status(500).json({
    success: false,
    message: 'Internal server error in employee routes',
    error: error.message
  });
});

module.exports = router;
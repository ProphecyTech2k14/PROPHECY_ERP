const { poolPromise, sql } = require("../../config/db");
const multer = require('multer');
const path = require('path');
const fs = require('fs');

// Configure multer storage
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const uploadDir = path.join(__dirname, '../../uploads/resumes');
    // Create directory if it doesn't exist
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const sanitizedOriginalName = file.originalname.replace(/[^a-zA-Z0-9.-]/g, '_');
    cb(null, uniqueSuffix + '-' + sanitizedOriginalName);
  }
});

// File filter to allow only certain file types
const fileFilter = (req, file, cb) => {
  console.log('File received:', file.originalname, file.mimetype);
  
  const allowedMimeTypes = [
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
  ];
  
  const allowedExtensions = ['.pdf', '.doc', '.docx'];
  const extname = path.extname(file.originalname).toLowerCase();
  
  if (allowedMimeTypes.includes(file.mimetype) && allowedExtensions.includes(extname)) {
    cb(null, true);
  } else {
    cb(new Error('Only PDF, DOC and DOCX files are allowed'), false);
  }
};

// Initialize multer with error handling
const upload = multer({ 
  storage: storage,
  fileFilter: fileFilter,
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
    files: 1 // Only allow 1 file
  }
});

// Middleware to handle file upload
exports.uploadResume = (req, res, next) => {
  upload.single('resume')(req, res, (err) => {
    if (err instanceof multer.MulterError) {
      console.error('Multer error:', err);
      if (err.code === 'LIMIT_FILE_SIZE') {
        return res.status(413).json({ message: 'File size too large. Maximum size is 5MB.' });
      }
      if (err.code === 'LIMIT_FILE_COUNT') {
        return res.status(400).json({ message: 'Too many files. Only one file allowed.' });
      }
      return res.status(400).json({ message: 'File upload error: ' + err.message });
    } else if (err) {
      console.error('File filter error:', err);
      return res.status(415).json({ message: err.message });
    }
    next();
  });
};

exports.createApplication = async (req, res) => {
  console.log('Creating application with data:', req.body);
  console.log('File uploaded:', req.file ? req.file.filename : 'No file');
  
  const { 
    roleId, 
    name, 
    email, 
    phone, 
    experience, 
    currentCompany, 
    expectedSalary, 
    noticePeriod, 
    location, 
    skills 
  } = req.body;
  
  try {
    // Validation
    if (!roleId || !name || !email || !phone || !experience) {
      // Delete uploaded file if validation fails
      if (req.file) {
        try {
          fs.unlinkSync(req.file.path);
        } catch (deleteErr) {
          console.error('Error deleting file:', deleteErr);
        }
      }
      return res.status(400).json({ message: "Required fields are missing" });
    }

    const pool = await poolPromise;
    
    // Check if role exists
    const roleCheck = await pool.request()
      .input("roleId", sql.Int, parseInt(roleId))
      .query("SELECT id FROM RecruitmentRoles WHERE id = @roleId");
    
    if (roleCheck.recordset.length === 0) {
      // Delete uploaded file if role doesn't exist
      if (req.file) {
        try {
          fs.unlinkSync(req.file.path);
        } catch (deleteErr) {
          console.error('Error deleting file:', deleteErr);
        }
      }
      return res.status(404).json({ message: "Role not found" });
    }
    
    // Check if email already applied for this role
    const emailCheck = await pool.request()
      .input("roleId", sql.Int, parseInt(roleId))
      .input("email", sql.NVarChar, email.toLowerCase().trim())
      .query("SELECT id FROM Applications WHERE roleId = @roleId AND email = @email");
    
    if (emailCheck.recordset.length > 0) {
      // Delete uploaded file if application exists
      if (req.file) {
        try {
          fs.unlinkSync(req.file.path);
        } catch (deleteErr) {
          console.error('Error deleting file:', deleteErr);
        }
      }
      return res.status(409).json({ message: "Candidate already applied for this role" });
    }
    
    // Get the resume URL if file was uploaded
    const resumeUrl = req.file ? `/uploads/resumes/${req.file.filename}` : null;
    
    console.log('Inserting application into database...');

    const insertResult = await pool.request()
      .input("roleId", sql.Int, parseInt(roleId))
      .input("name", sql.NVarChar, name.trim())
      .input("email", sql.NVarChar, email.toLowerCase().trim())
      .input("phone", sql.NVarChar, phone.trim())
      .input("experience", sql.NVarChar, experience.trim())
      .input("currentCompany", sql.NVarChar, currentCompany?.trim() || null)
      .input("expectedSalary", sql.NVarChar, expectedSalary?.trim() || null)
      .input("noticePeriod", sql.NVarChar, noticePeriod?.trim() || null)
      .input("location", sql.NVarChar, location?.trim() || null)
      .input("skills", sql.NVarChar, skills?.trim() || null)
      .input("resumeUrl", sql.NVarChar, resumeUrl)
      .query(`
        INSERT INTO Applications (
          roleId, name, email, phone, experience, currentCompany,
          expectedSalary, noticePeriod, location, skills, resumeUrl, status, currentStep
        )
        VALUES (
          @roleId, @name, @email, @phone, @experience, @currentCompany,
          @expectedSalary, @noticePeriod, @location, @skills, @resumeUrl, 'Applied', 0
        )
      `);
    
    console.log('Application inserted successfully');
    
    // Update application count in role
    await pool.request()
      .input("roleId", sql.Int, parseInt(roleId))
      .query(`
        UPDATE RecruitmentRoles
        SET applicationCount = (
          SELECT COUNT(*) FROM Applications WHERE roleId = @roleId
        )
        WHERE id = @roleId
      `);
    
    console.log('Application count updated');
    
    res.status(201).json({ 
      message: "Application submitted successfully",
      resumeUploaded: !!req.file
    });
    
  } catch (error) {
    // Delete uploaded file if error occurs
    if (req.file) {
      try {
        fs.unlinkSync(req.file.path);
      } catch (deleteErr) {
        console.error('Error deleting file:', deleteErr);
      }
    }
    
    console.error("Error creating application:", error);
    console.error("Error stack:", error.stack);
    
    // Check for specific SQL errors
    if (error.code === 'EREQUEST') {
      return res.status(400).json({ 
        message: "Database validation error", 
        error: error.message 
      });
    }
    
    res.status(500).json({ 
      message: "Server error while creating application", 
      error: error.message 
    });
  }
};

exports.updateApplicationStatus = async (req, res) => {
  const applicationId = req.params.id;
  const { currentStep, status } = req.body;
  
  try {
    const pool = await poolPromise;
    
    await pool.request()
      .input("id", sql.Int, parseInt(applicationId))
      .input("currentStep", sql.Int, parseInt(currentStep))
      .input("status", sql.NVarChar, status)
      .query(`
        UPDATE Applications
        SET currentStep = @currentStep, status = @status, updatedAt = GETDATE()
        WHERE id = @id
      `);
    
    res.status(200).json({ message: "Application status updated successfully" });
  } catch (error) {
    console.error("Error updating application status:", error);
    res.status(500).json({ message: "Server error while updating status", error: error.message });
  }
};

exports.getApplicationHiringSteps = async (req, res) => {
  try {
    const pool = await poolPromise;
    const result = await pool.request().query(`
      SELECT id, stepName, stepOrder
      FROM HiringSteps
      WHERE isActive = 1
      ORDER BY stepOrder
    `);
    
    res.status(200).json(result.recordset);
  } catch (error) {
    console.error("Error fetching hiring steps:", error);
    res.status(500).json({ message: "Server error while fetching steps", error: error.message });
  }
};

// Serve resume files with permission checks
exports.serveResume = async (req, res) => {
  try {
    const filename = req.params.filename;
    const uploadDir = path.join(__dirname, '../../uploads/resumes');
    const filePath = path.join(uploadDir, filename);

    // Check if file exists
    if (!fs.existsSync(filePath)) {
      console.error('Resume not found at path:', filePath);
      return res.status(404).json({ message: "Resume not found" });
    }

    // Check if user has permission to view this resume
    const pool = await poolPromise;
    const result = await pool.request()
      .input("filename", sql.NVarChar, filename)
      .query(`
        SELECT a.id, rr.recruiter, rr.assignTo 
        FROM Applications a
        JOIN RecruitmentRoles rr ON a.roleId = rr.id
        WHERE a.resumeUrl LIKE '%' + @filename
      `);

    if (result.recordset.length === 0) {
      return res.status(404).json({ message: "Resume record not found" });
    }

    const application = result.recordset[0];
    const currentUser = req.user.username;
    const currentUserRole = req.user.role;

    // Check permissions:
    // - Managers can view all resumes
    // - Recruiters can view resumes for roles assigned to them
    if (currentUserRole !== 'manager' && 
        application.assignTo !== currentUser && 
        application.recruiter !== req.user.userId) {
      return res.status(403).json({ message: "Unauthorized to view this resume" });
    }

    // Get file stats
    const stats = fs.statSync(filePath);
    
    // Set content type based on extension
    const ext = path.extname(filename).toLowerCase();
    let contentType = 'application/octet-stream';
    
    switch (ext) {
      case '.pdf': 
        contentType = 'application/pdf'; 
        break;
      case '.doc': 
        contentType = 'application/msword'; 
        break;
      case '.docx': 
        contentType = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'; 
        break;
    }
    
    // Set headers
    res.setHeader('Content-Type', contentType);
    res.setHeader('Content-Length', stats.size);
    res.setHeader('Accept-Ranges', 'bytes');
    
    // For Word documents, force download instead of inline display
    if (ext === '.doc' || ext === '.docx') {
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    } else {
      res.setHeader('Content-Disposition', `inline; filename="${filename}"`);
    }
    
    // Handle range requests for better browser compatibility
    const range = req.headers.range;
    if (range) {
      const parts = range.replace(/bytes=/, "").split("-");
      const start = parseInt(parts[0], 10);
      const end = parts[1] ? parseInt(parts[1], 10) : stats.size - 1;
      const chunksize = (end - start) + 1;
      
      res.status(206);
      res.setHeader('Content-Range', `bytes ${start}-${end}/${stats.size}`);
      res.setHeader('Content-Length', chunksize);
      
      const stream = fs.createReadStream(filePath, { start, end });
      stream.pipe(res);
    } else {
      // Create read stream
      const fileStream = fs.createReadStream(filePath);
      fileStream.on('error', (error) => {
        console.error('Error streaming resume:', error);
        if (!res.headersSent) {
          res.status(500).json({ message: "Error serving resume" });
        }
      });
      
      fileStream.pipe(res);
    }
    
  } catch (error) {
    console.error("Error serving resume:", error);
    if (!res.headersSent) {
      res.status(500).json({ 
        message: "Server error while serving resume",
        error: error.message 
      });
    }
  }
};
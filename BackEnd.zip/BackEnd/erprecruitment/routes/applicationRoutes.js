// const express = require("express");
// const router = express.Router();
// const {
//   createApplication,
//   updateApplicationStatus,
//   getApplicationHiringSteps
// } = require("../controllers/applicationController");
// const { authenticateToken } = require("../../Recruitment/middleWare/authMiddleware");

// router.post("/", authenticateToken, createApplication);
// router.put("/:id/status", authenticateToken, updateApplicationStatus);
// router.get("/hiring-steps", authenticateToken, getApplicationHiringSteps);

// module.exports = router;



const express = require("express");
const router = express.Router();
const {
  createApplication,
  updateApplicationStatus,
  getApplicationHiringSteps,
  uploadResume,
  serveResume
} = require("../controllers/applicationController");
const { authenticateToken } = require("../../Recruitment/middleWare/authMiddleware");

router.post("/", authenticateToken, uploadResume, createApplication);
router.put("/:id/status", authenticateToken, updateApplicationStatus);
router.get("/hiring-steps", authenticateToken, getApplicationHiringSteps);
router.get("/uploads/resumes/:filename", authenticateToken, serveResume);
module.exports = router;
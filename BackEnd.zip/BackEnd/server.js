
require("dotenv").config();
const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const path = require("path");
// const { errorHandler } = require('./erprecruitment/utils/error-handler');
const app = express();

// ✅ CORS Middleware
app.use(cors({
  origin: "*", // Replace with frontend URL in production
  methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
  credentials: true,
  allowedHeaders: ["Content-Type", "Authorization"]
}));

// ✅ Body Parsers
app.use(express.json());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// ✅ Serve static files (e.g., profile uploads)
app.use("/uploads", express.static(path.join(__dirname, "Recruitment", "public", "uploads")));
// In your main app.js/server.js
// Replace the two uploads lines with:
app.use('/uploads/resumes', express.static(path.join(__dirname, 'uploads', 'resumes')));
// ✅ API Routes
app.use("/api/auth", require("./Recruitment/routes/AuthRoutes"));

app.use("/api/recruitment/roles", require("./erprecruitment/routes/recruitmentRoutes"));
app.use("/api/recruitment/recruiters", require("./erprecruitment/routes/recruiterRoutes"));
app.use("/api/recruitment/applications", require("./erprecruitment/routes/applicationRoutes"));



// ✅ 404 Handler
app.use((req, res) => {
  res.status(404).json({ message: "API route not found" });
});

// ✅ Start Server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});





const { sql, poolPromise } = require("../../config/db"); 
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
require("dotenv").config();

// ✅ Secure User Login with First Name
exports.login = async (req, res) => {
  try {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({ error: "Username and password are required!" });
    }

    const pool = await poolPromise;

    // ✅ Join userinfo and userdetails to also get firstName
    const result = await pool
      .request()
      .input("username", sql.NVarChar, username)
      .query(`
        SELECT 
          u.id, 
          u.username, 
          u.password, 
          u.role, 
          u.profile,
          d.firstName
        FROM userinfo u
        INNER JOIN userdetails d ON u.id = d.id
        WHERE u.username = @username
      `);

    if (result.recordset.length === 0) {
      return res.status(401).json({ error: "Invalid username or password" });
    }

    const user = result.recordset[0];

    const passwordMatch = await bcrypt.compare(password, user.password);
    if (!passwordMatch) {
      return res.status(401).json({ error: "Invalid username or password" });
    }

    const profile = user.profile || "";

    const token = jwt.sign(
      { userId: user.id, username: user.username, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: "8h" }
    );

    res.status(200).json({ 
      message: "Login successful!", 
      token, 
      user: { 
        id: user.id, 
        username: user.username, 
        firstName: user.firstName,
        role: user.role,
        profile: profile 
      },
      // Add view information based on role
      view: user.role === 'manager' ? 'manager' : 'recruiter'
    });

  } catch (err) {
    console.error("Login Error:", err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

// Get current user information
exports.getCurrentUser = async (req, res) => {
  try {
    const userId = req.user.userId;
    
    const pool = await poolPromise;
    const result = await pool
      .request()
      .input("id", sql.Int, userId)
      .query(`
        SELECT 
          u.id, 
          u.username, 
          u.role, 
          u.profile,
          d.firstName
        FROM userinfo u
        INNER JOIN userdetails d ON u.id = d.id
        WHERE u.id = @id
      `);

    if (result.recordset.length === 0) {
      return res.status(404).json({ error: "User not found" });
    }

    const user = result.recordset[0];
    
    res.status(200).json({
      id: user.id,
      username: user.username,
      firstName: user.firstName,
      role: user.role,
      profile: user.profile || "",
      view: user.role === 'manager' ? 'manager' : 'recruiter'
    });
  } catch (error) {
    console.error("Error fetching current user:", error);
    res.status(500).json({ message: "Server error while fetching user data" });
  }
};
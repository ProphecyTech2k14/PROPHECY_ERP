
const express = require("express");
const { login, getCurrentUser } = require("../controllers/authController");
const { authenticateToken } = require("../middleWare/authMiddleware");
const { poolPromise, sql } = require("../../config/db");
// const upload = require("../middleWare/uploadMiddleware");
const fs = require("fs");
const path = require("path");

const router = express.Router();

// Login route
router.post("/login", login);

// Get current user route
router.get('/me', authenticateToken, getCurrentUser);

// Get users by role with token verification
router.get("/role/:role", authenticateToken, async (req, res) => {
  try {
    const { role } = req.params;
    const currentUserRole = req.user.role;

    // Only allow managers to access this route
    if (currentUserRole !== 'manager') {
      return res.status(403).json({ error: "Access denied. Manager role required." });
    }

    if (!role) {
      return res.status(400).json({ error: "Role is required!" });
    }

    const pool = await poolPromise;
    const result = await pool
      .request()
      .input("role", sql.NVarChar, role)
      .query(`
        SELECT 
          u.id,
          u.username,
          u.role,
          u.profile,
          d.firstName,
          d.lastName,
          d.alias,
          d.email,
          d.phone,
          d.mobile,
          d.fax,
          d.website,
          d.dob,
          d.street,
          d.city,
          d.province,
          d.postalCode,
          d.country,
          d.created_at,
          d.updated_at
        FROM userinfo u
        JOIN userdetails d ON u.id = d.id
        WHERE LOWER(u.role) = LOWER(@role)
      `);

    res.status(200).json({ users: result.recordset });
  } catch (error) {
    console.error("Error fetching users by role:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// Fetch all users - for admin only
router.get("/users", authenticateToken, async (req, res) => {
  try {
    const currentUserRole = req.user.role;

    // Only allow managers to access this route
    if (currentUserRole !== 'manager') {
      return res.status(403).json({ error: "Access denied. Manager role required." });
    }

    const pool = await poolPromise;
    const result = await pool
      .request()
      .query(`
        SELECT 
          u.id,
          u.username,
          u.role,
          u.profile,
          d.firstName,
          d.lastName,
          d.alias,
          d.email,
          d.phone,
          d.mobile,
          d.fax,
          d.website,
          d.dob,
          d.street,
          d.city,
          d.province,
          d.postalCode,
          d.country,
          d.created_at,
          d.updated_at
        FROM userinfo u
        JOIN userdetails d ON u.id = d.id
      `);

    res.status(200).json({ users: result.recordset });
  } catch (error) {
    console.error("Error fetching all users with details:", error);
    res.status(500).json({ error: error.message });
  }
});



module.exports = router;